import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient

# 2. 타겟 페이지에서 데이터 가져오기
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'}
data = requests.get(
    'https://www.10000recipe.com/recipe/list.html?q=&query=&cat1=&cat2=&cat3=70&cat4=56&fct=&order=reco&lastcate=cat4&dsearch=&copyshot=&scrap=&degree=&portion=&time=&niresource=',
    headers=headers)

# 2-B. 타겟 페이지에서 데이터 가져오기
# client로서 DB에 들어가서 localhost인 내컴퓨터로 27017 로 들어가는 것. 신원 확인
client = MongoClient('localhost', 27017)
# 내가 원하는 db 안에서의 선반 이름은 dbsparta라는 선반으로 가.
db = client.dbsparta  # dbsparta = 선반 이름

# 4. 읽은 데이터를, html 문법에 맞게 다시 읽고, soup에 넣어준다!
# data.text: data의 text만 가져올거야.
# BeautifulSoup() 안에 넣으면 그 soup 안에 넣어줘
# html.parser: html 파일이니 그걸 문법으로 읽어줘

soup = BeautifulSoup(data.text, 'html.parser')

# 원하는 거만 떠보자! => 가장 가까운 부모부터 파고 들어간다
# soup.select: soup에서 원하는 것만 골라.
# '#old_content' old_content라는 id를를가진 애한테 가
recipes = soup.select('#contents_area_full > ul > ul > li')
# print(recipes)
for recipe in recipes:
    # xx.select_one: 여러가지 중 하나만 잡는 것 (맨 처음 하나)
    # td.title: td에 class 이름이 title로 달려있는 거
    div_tag = recipe.select_one('div.common_sp_caption > div.common_sp_caption_tit')
    if div_tag == None:
        pass
    else:
        # div_tag.text: 그 중 데이터에 text만 가져와
        title = div_tag.text  # title
        url = recipe.select_one('div.common_sp_thumb > a')['href']
        # rank = movie.select_one('td.ac > img')['alt']
        # star = movie.select_one('td.point').text
        full_url = 'https://www.10000recipe.com' + url
        recipe_data = requests.get(full_url, headers=headers)
        recipe_soup = BeautifulSoup(recipe_data.text, 'html.parser')
        # 시도 1.
        # recipes_detail = recipe_soup.select('#body > script:nth-child(19)')
        # 시도 2.
        # recipes_detail = json.loads(soup.find('script', type="application/ld+json").string)
        # print(full_url)
        ##### ingredients
        # Total ingredients # divConfirmedMaterialArea
        main_ingre = recipe_soup.select('#divConfirmedMaterialArea > ul:nth-of-type(1) > a > li')
        ###
        # MAIN INGREDIENTS: 예쁘게 재료 정보를 추출해주는 크롤링 코드
        ###
        for ingredient in main_ingre:
            ingre_container = []  # ingredient 정보를 넣어줄 공간
            ingre_name = ingredient.text
            ingre_name = ingre_name.split('\n')  # ['차돌박이                                                        ', '10장', '']

            for ingre in ingre_name:
                cleaned_ingre = ingre.strip()  # strip: 띄어쓰기 삭제!
                ingre_container.append(cleaned_ingre)
            ingre_container = ingre_container[:2]
            # print(ingre_container)
        ###
        # SIDE INGREDIENTS 추출하기
        ###
        side_ingre = recipe_soup.select('#divConfirmedMaterialArea > ul:nth-of-type(2)')
        side_name = recipe_soup.select('#divConfirmedMaterialArea > ul:nth-of-type(2) > b')
        side_name = side_name.text
        print(side_name)
        # for ingredient in side_ingre:
        #     side_ingre_container = []



        # for ingredient in side_ingre:




    # main_ingre_img_src = main_ingre.select_one('img')['src']
    # main_ingre_unit = main_ingre.select_one('span').text
    # side_ingre = recipe_soup.select_one('#divConfirmedMaterialArea > ul:nth-of-type(2)')
    # # print(ingredients)
    # print(main_ingre)
    # print(main_ingre_img_src)
    # print(main_ingre_unit)

    # print(side_ing)
# Main ingredients #divConfirmedMaterialArea > ul:nth-child(1)
# Sauce ingredients #divConfirmedMaterialArea > ul:nth-child(2)
##### recipe


# print(recipe_soup)
# print(recipes_detail)
# print(full_url)
# pocket = {
#     'title' : title,
#     'url' : url,
#     # 'star' : star
#
# }
# db.movies.insert_one(pocket)
# print('[DB알림]', title, url, '데이터를 성공적으로 저장했습니다!')

# dbsparta 의 컨테이너가 있는데 그중 하나의 선반으로 movies 에 가서 pocket 데이터를 insert one 할 예정.
